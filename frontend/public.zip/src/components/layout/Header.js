import React, { useContext } from 'react';
import { Navbar, Container, Nav, Button } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../../context/AuthContext';
import { ThemeContext } from '../../context/ThemeContext';
import styled from 'styled-components';

// Styled components for the header
const StyledNavbar = styled(Navbar)`
  padding: 0.8rem 1rem;
  transition: var(--transition-medium);
  box-shadow: var(--shadow-sm);
`;

const NavbarBrand = styled(Navbar.Brand)`
  font-size: 1.5rem;
  font-weight: 700;
  display: flex;
  align-items: center;
  
  .brand-emoji {
    font-size: 1.8rem;
    margin-right: 0.5rem;
  }
`;

const ThemeToggleButton = styled.button`
  background: transparent;
  border: none;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-size: 1.2rem;
  margin-right: 1rem;
  color: var(--text);
  transition: var(--transition-medium);
  
  &:hover {
    background-color: rgba(128, 128, 128, 0.1);
  }
`;

const UserAvatar = styled.div`
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background-color: var(--primary);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 0.5rem;
  font-weight: bold;
`;

const Header = () => {
  const { user, logout, isAuthenticated } = useContext(AuthContext);
  const { theme, toggleTheme } = useContext(ThemeContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <StyledNavbar expand="lg">
      <Container>
        <NavbarBrand as={Link} to="/" className="text-primary">
          <span className="brand-emoji">🐾</span>
          PetHaven
        </NavbarBrand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/" className="mx-1">Início</Nav.Link>
            <Nav.Link as={Link} to="/animals" className="mx-1">Animais</Nav.Link>
            <Nav.Link as={Link} to="/ngos" className="mx-1">ONGs</Nav.Link>
            {isAuthenticated && (
              <Nav.Link as={Link} to="/adoptions" className="mx-1">Minhas Adoções</Nav.Link>
            )}
          </Nav>
          <Nav className="d-flex align-items-center">
            <ThemeToggleButton onClick={toggleTheme} aria-label="Toggle theme">
              {theme === 'light' ? '🌙' : '☀️'}
            </ThemeToggleButton>
            
            {isAuthenticated ? (
              <div className="d-flex align-items-center">
                <Nav.Link as={Link} to="/profile" className="d-flex align-items-center me-2">
                  <UserAvatar>{user.username ? user.username.charAt(0).toUpperCase() : 'U'}</UserAvatar>
                  <span>Olá, {user.username}</span>
                </Nav.Link>
                <Button 
                  variant="outline-primary" 
                  onClick={handleLogout}
                  className="rounded-pill px-3"
                >
                  Sair
                </Button>
              </div>
            ) : (
              <div className="d-flex align-items-center">
                <Nav.Link as={Link} to="/login" className="me-2">Entrar</Nav.Link>
                <Button 
                  variant="primary" 
                  as={Link} 
                  to="/register"
                  className="rounded-pill px-3"
                >
                  Cadastrar
                </Button>
              </div>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </StyledNavbar>
  );
};

export default Header;
